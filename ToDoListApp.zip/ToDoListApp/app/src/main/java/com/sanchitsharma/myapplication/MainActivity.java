package com.sanchitsharma.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> todoList;
    ArrayAdapter<String> arrayAdapter;
    ListView listview;

    EditText edittext;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        todoList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this, R.layout.list_view_layout, todoList);
        listview = findViewById(R.id.mainListView);

        listview.setAdapter(arrayAdapter);
        listview.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView text = (TextView) view;
                text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            }
        });

        //listview.setOnItemSelectedListener();

        edittext = findViewById(R.id.inputTextView);
        save = findViewById(R.id.Savebutton);


    }

    public void saveTask(View view) {
        todoList.add(edittext.getText().toString());
        arrayAdapter.notifyDataSetChanged();

        edittext.setText("");

    }
}
